export * from "./text-generate-effect";
