/**
 * Auto-generated CV data for portfolio
 * Generated at: 2025-07-24T23:34:42.915286
 * User: 1e3e5b7e-c0aa-4b20-82e9-4c2bdb92e0c4
 * Job ID: michelle_enhanced_demo
 */

import { adaptCV2WebToTemplate } from './cv-data-adapter'

// CV Data from extraction
const extractedCVData = {
  "hero": {
    "fullName": "MICHELLE JEWETT",
    "professionalTitle": "Digital Marketing Specialist & Content Creator",
    "summaryTagline": "Recent Bachelor of Marketing & Business Management graduate with hands-on experience in digital marketing, web development, and content creation. Passionate about leveraging technology to drive marketing success.",
    "profilePhotoUrl": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400"
  },
  "contact": {
    "email": "michelle.jewett@email.com",
    "phone": "(541) 754-3010",
    "location": {
      "city": "Los Angeles",
      "state": "California",
      "country": "United States"
    },
    "professionalLinks": [
      {
        "platform": "LinkedIn",
        "url": "https://linkedin.com/in/michellejewett"
      },
      {
        "platform": "GitHub",
        "url": "https://github.com/michellejewett"
      },
      {
        "platform": "Portfolio",
        "url": "https://michellejewett.com"
      }
    ],
    "availability": "Available for full-time opportunities"
  },
  "summary": {
    "summaryText": "Recent Bachelor of Marketing & Business Management graduate with a passion for digital marketing and web development. Experienced in creating websites, managing social media campaigns, and analyzing market data. Strong track record of delivering results through internships at major companies including Coca-Cola. Seeking to leverage my technical skills and marketing knowledge to drive digital transformation initiatives.",
    "yearsOfExperience": 3,
    "keySpecializations": [
      "Digital Marketing",
      "Web Development",
      "Content Creation",
      "Data Analysis"
    ],
    "careerHighlights": [
      "Created 3 university websites in 2 months",
      "Managed 5000+ client database",
      "Dean's list for 8 semesters"
    ]
  },
  "experience": {
    "sectionTitle": "Employment History",
    "experienceItems": [
      {
        "jobTitle": "University News Paper Editor & Web Developer",
        "companyName": "Columbus State University",
        "location": {
          "city": "Boston",
          "state": "Massachusetts",
          "country": "United States"
        },
        "dateRange": {
          "startDate": "NOVEMBER 2016",
          "endDate": "FEBRUARY 2019",
          "isCurrent": false
        },
        "remoteWork": null,
        "responsibilitiesAndAchievements": [
          "Created three new websites for the Columbus State University's marketing, engineering and medical faculties within a period of two months",
          "Responsible for weekly editor's comments for the newspaper",
          "Proofread and edit write ups from staff members",
          "Managed social media presence and increased engagement by 150%"
        ],
        "technologiesUsed": [
          "HTML",
          "WordPress",
          "Adobe Creative Suite",
          "Social Media Management"
        ],
        "summary": null,
        "employmentType": null,
        "teamSize": null,
        "reportingTo": null
      },
      {
        "jobTitle": "Marketing Intern",
        "companyName": "Coca Cola",
        "location": null,
        "dateRange": {
          "startDate": "JUNE 2017",
          "endDate": "SEPTEMBER 2017",
          "isCurrent": false
        },
        "remoteWork": null,
        "responsibilitiesAndAchievements": [
          "Update database of 5000 clients using MS Access and categorize data in accordance with client demographics",
          "Accumulate quantitative and qualitative data to prepare market studies and analytics",
          "Conduct competitor analysis",
          "Created data visualization dashboards for marketing team"
        ],
        "technologiesUsed": [
          "MS Access",
          "Excel",
          "Data Analytics",
          "PowerBI"
        ],
        "summary": null,
        "employmentType": "Internship",
        "teamSize": null,
        "reportingTo": null
      },
      {
        "jobTitle": "Business Management Intern",
        "companyName": "Boston Legal",
        "location": {
          "city": "Boston",
          "state": "Massachusetts",
          "country": "United States"
        },
        "dateRange": {
          "startDate": "JULY 2018",
          "endDate": "SEPTEMBER 2018",
          "isCurrent": false
        },
        "remoteWork": null,
        "responsibilitiesAndAchievements": [
          "Instrumental in transferring 2000 client files onto the new digital CRM system",
          "Assist with general office work in HR and operational departments",
          "Assist in the write up of policies and procedures",
          "Check production reports and comparing with financial reports",
          "Assist in updating safety documentation on the company system"
        ],
        "technologiesUsed": [
          "CRM Systems",
          "Microsoft Office",
          "Data Migration"
        ],
        "summary": null,
        "employmentType": "Internship",
        "teamSize": null,
        "reportingTo": null
      },
      {
        "jobTitle": "General Intern",
        "companyName": "Florida County Healthcare Association",
        "location": {
          "city": "Tampa",
          "state": "Florida",
          "country": "United States"
        },
        "dateRange": {
          "startDate": "MARCH 2016",
          "endDate": "AUGUST 2016",
          "isCurrent": false
        },
        "remoteWork": null,
        "responsibilitiesAndAchievements": [
          "Instrumental in organizing the weekly Q&A session between management and members of the association and handled all email correspondence preceding and following these events",
          "Answer phone inquiries, direct calls and take messages",
          "Schedule travel arrangements of directors",
          "Receive and post packages and registered letters from couriers",
          "Taking minutes and distributing notes after meetings"
        ],
        "technologiesUsed": null,
        "summary": null,
        "employmentType": "Internship",
        "teamSize": null,
        "reportingTo": null
      }
    ]
  },
  "education": {
    "sectionTitle": "Education",
    "educationItems": [
      {
        "degree": "Bachelor of Marketing & Business Management",
        "fieldOfStudy": "Marketing",
        "institution": "Columbus State University",
        "location": {
          "city": "Atlanta",
          "state": "Georgia",
          "country": "United States"
        },
        "dateRange": {
          "startDate": "SEPTEMBER 2016",
          "endDate": "FEBRUARY 2019",
          "isCurrent": null
        },
        "gpa": "3.6",
        "honors": [
          "Honors Program",
          "Dean's list for 8 Semesters"
        ],
        "minors": [
          "Political Science",
          "Communications",
          "Economics"
        ],
        "relevantCoursework": null,
        "exchangePrograms": null
      },
      {
        "degree": "High School Diploma",
        "fieldOfStudy": null,
        "institution": "Hawthorne High School",
        "location": {
          "city": "Boston",
          "state": "Massachusetts",
          "country": "United States"
        },
        "dateRange": {
          "startDate": null,
          "endDate": "FEBRUARY 2016",
          "isCurrent": null
        },
        "gpa": "3.7",
        "honors": null,
        "minors": null,
        "relevantCoursework": null,
        "exchangePrograms": null
      },
      {
        "degree": "Advanced Excel Course",
        "fieldOfStudy": null,
        "institution": "ICT Computer College",
        "location": null,
        "dateRange": {
          "startDate": null,
          "endDate": "OCTOBER 2017",
          "isCurrent": null
        },
        "gpa": null,
        "honors": null,
        "minors": null,
        "relevantCoursework": null,
        "exchangePrograms": null
      }
    ]
  },
  "skills": {
    "sectionTitle": "Skills",
    "skillCategories": [
      {
        "categoryName": "Software Skills",
        "skills": [
          "Microsoft Word - Expert level with 5+ years experience",
          "PowerPoint - Advanced presentation design",
          "Excel - Advanced data analysis and pivot tables",
          "VisualStudio",
          "Adobe Photoshop - Professional image editing",
          "Dreamweaver MX",
          "Flash MX",
          "Oracle"
        ]
      },
      {
        "categoryName": "Web Development",
        "skills": [
          "HTML - Certified by Udemy",
          "WordPress - Built 3 university websites",
          "CSS - Basic styling knowledge",
          "JavaScript - Learning in progress"
        ]
      },
      {
        "categoryName": "Professional Skills",
        "skills": [
          "Budgets",
          "Team Player",
          "Deadline Driven",
          "Energetic",
          "Collaboration",
          "Project Management"
        ]
      }
    ],
    "ungroupedSkills": null,
    "proficiencyIndicators": null
  },
  "projects": {
    "sectionTitle": "Featured Projects",
    "projectItems": [
      {
        "title": "University Faculty Websites",
        "role": "Lead Developer",
        "duration": "two months",
        "dateRange": {
          "startDate": "NOVEMBER 2018",
          "endDate": "JANUARY 2019",
          "isCurrent": null
        },
        "description": "Created three new responsive websites for Columbus State University's marketing, engineering and medical faculties. Implemented modern design principles and ensured mobile compatibility.",
        "keyFeatures": [
          "Responsive Design",
          "SEO Optimization",
          "Content Management System"
        ],
        "technologiesUsed": [
          "WordPress",
          "HTML",
          "CSS",
          "JavaScript"
        ],
        "projectUrl": "https://csu.edu/faculties",
        "githubUrl": "https://github.com/vercel/next.js",
        "imageUrl": "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800",
        "projectMetrics": null
      },
      {
        "title": "Marketing Campaign Dashboard",
        "role": "Data Analyst Intern",
        "duration": "3 months",
        "dateRange": {
          "startDate": "JUNE 2017",
          "endDate": "SEPTEMBER 2017",
          "isCurrent": null
        },
        "description": "Developed an interactive dashboard for Coca-Cola's marketing team to track campaign performance across 5000+ clients. Included real-time analytics and demographic insights.",
        "keyFeatures": [
          "Real-time Analytics",
          "Client Segmentation",
          "Performance Metrics"
        ],
        "technologiesUsed": [
          "PowerBI",
          "Excel",
          "SQL"
        ],
        "projectUrl": "https://twitter.com/CocaCola/status/1234567890123456789",
        "videoUrl": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        "imageUrl": null,
        "projectMetrics": {
          "clientsTracked": 5000,
          "reportsGenerated": 50
        }
      },
      {
        "title": "Student News Blog Platform",
        "role": "Editor & Developer",
        "duration": "2 years",
        "dateRange": {
          "startDate": "NOVEMBER 2016",
          "endDate": "FEBRUARY 2019",
          "isCurrent": null
        },
        "description": "Managed and enhanced the university newspaper's digital platform. Increased readership by 150% through SEO optimization and social media integration.",
        "keyFeatures": [
          "Content Management",
          "SEO Optimization",
          "Social Media Integration"
        ],
        "technologiesUsed": [
          "WordPress",
          "PHP",
          "MySQL"
        ],
        "projectUrl": "https://csunews.edu",
        "githubUrl": "https://github.com/facebook/react",
        "demoUrl": "https://vimeo.com/824804225",
        "imageUrl": "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800",
        "projectMetrics": {
          "monthlyReaders": 10000,
          "articlesPublished": 200
        }
      }
    ]
  },
  "achievements": {
    "sectionTitle": "Key Achievements",
    "achievements": [
      {
        "value": "3",
        "label": "new websites created",
        "contextOrDetail": "for the Columbus State University's marketing, engineering and medical faculties",
        "timeframe": "within a period of two months"
      },
      {
        "value": "8 Semesters",
        "label": "Dean's list",
        "contextOrDetail": "Maintained GPA above 3.5 throughout university",
        "timeframe": null
      },
      {
        "value": "State Champions",
        "label": "Captain of Athletics Team",
        "contextOrDetail": "Led team to state championship victory",
        "timeframe": "2016"
      },
      {
        "value": "150%",
        "label": "increase in readership",
        "contextOrDetail": "for university newspaper through digital transformation",
        "timeframe": "2016-2019"
      },
      {
        "value": "5000",
        "label": "clients database managed",
        "contextOrDetail": "using MS Access with advanced categorization",
        "timeframe": null
      },
      {
        "value": "2000",
        "label": "client files migrated",
        "contextOrDetail": "to new digital CRM system with zero data loss",
        "timeframe": null
      }
    ]
  },
  "certifications": {
    "sectionTitle": "Certifications",
    "certificationItems": [
      {
        "title": "Certificate in HTML",
        "issuingOrganization": "Udemy Online",
        "issueDate": "APRIL 2018",
        "expirationDate": null,
        "credentialId": "UC-123456789",
        "verificationUrl": "https://www.udemy.com/certificate/UC-123456789"
      },
      {
        "title": "Google Analytics Certified",
        "issuingOrganization": "Google",
        "issueDate": "JANUARY 2019",
        "expirationDate": "JANUARY 2021",
        "credentialId": "GA-987654321",
        "verificationUrl": "https://skillshop.credential.net/123456"
      }
    ]
  },
  "languages": {
    "sectionTitle": "Languages",
    "languageItems": [
      {
        "language": "English",
        "proficiency": "Native",
        "certification": null
      },
      {
        "language": "German",
        "proficiency": "Intermediate (B1)",
        "certification": "Goethe Certificate"
      },
      {
        "language": "Spanish",
        "proficiency": "Basic",
        "certification": null
      }
    ]
  },
  "courses": {
    "sectionTitle": "Professional Development",
    "courseItems": [
      {
        "title": "Certificate in HTML",
        "institution": "Udemy Online",
        "year": "2018",
        "dateRange": {
          "startDate": "APRIL 2018",
          "endDate": null,
          "isCurrent": null
        },
        "certificateNumber": "UC-123456789",
        "certificateUrl": "https://www.udemy.com/certificate/UC-123456789",
        "description": "Comprehensive HTML5 course covering semantic markup and modern web standards"
      },
      {
        "title": "Advanced Excel Course",
        "institution": "ICT Computer College",
        "year": "2017",
        "dateRange": {
          "startDate": "OCTOBER 2017",
          "endDate": null,
          "isCurrent": null
        },
        "certificateNumber": null,
        "certificateUrl": null,
        "description": "Advanced data analysis, pivot tables, and VBA programming"
      }
    ]
  },
  "volunteer": {
    "sectionTitle": "Volunteering",
    "volunteerItems": [
      {
        "role": "Weekend Care Giver",
        "organization": "Sunshine Retirement Village",
        "location": {
          "city": "Boston",
          "state": "MA",
          "country": "United States"
        },
        "dateRange": {
          "startDate": "JULY 2012",
          "endDate": "JUNE 2015",
          "isCurrent": null
        },
        "description": "Provided companionship and assistance to elderly residents, organizing weekly activities and helping with daily tasks.",
        "responsibilities": [
          "Assisting residents with shopping and banking activities",
          "Organize weekly Bingo games and social events",
          "Coordinate with healthcare providers for resident needs"
        ],
        "impactMetrics": "Helped 50+ residents improve quality of life",
        "commitment": null,
        "period": null
      }
    ]
  },
  "publications": {
    "sectionTitle": "Publications & Media",
    "publications": [
      {
        "title": "The Future of Digital Marketing in Higher Education",
        "publicationType": "Article",
        "publicationVenue": "CSU Marketing Journal",
        "publicationDate": "2019",
        "url": "https://csujournal.edu/digital-marketing-2019"
      },
      {
        "title": "Building Responsive Websites for Universities",
        "publicationType": "Video Tutorial",
        "publicationVenue": "YouTube",
        "publicationDate": "2018",
        "url": "https://www.youtube.com/watch?v=abc123def456"
      }
    ]
  },
  "speaking": {
    "sectionTitle": "Speaking Engagements",
    "speakingEngagements": [
      {
        "eventName": "CSU Tech Conference 2019",
        "topic": "Web Development for Non-Profits",
        "date": "2019-02-15",
        "venue": "https://www.youtube.com/watch?v=speaking123",
        "role": "Keynote Speaker",
        "audienceSize": 200
      }
    ]
  },
  "patents": null,
  "memberships": null,
  "hobbies": {
    "sectionTitle": "Hobbies & Interests",
    "hobbies": [
      "Writing - Tech blog with 1000+ subscribers",
      "Blogging - Personal marketing insights blog",
      "Website Design - Freelance projects",
      "Running - Completed 3 marathons",
      "Photography - Nature and portrait photography",
      "Digital Art - Creating graphics for social media"
    ]
  },
  "unclassified_text": null
}

// Convert CV data to template format
export const portfolioData = adaptCV2WebToTemplate(extractedCVData)

// Force use of real data instead of sample data
export const useRealData = true
