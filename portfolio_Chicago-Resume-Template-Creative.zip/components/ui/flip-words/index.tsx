export { FlipWords } from "./flip-words-base";
export { FlipWordsHeroTitle } from "./flip-words-hero-title";
export { FlipWordsTestimonialHighlight } from "./flip-words-testimonial-highlight";
export { FlipWordsFeatureShowcase } from "./flip-words-feature-showcase";

export type { FlipWordsProps } from "./flip-words.types";