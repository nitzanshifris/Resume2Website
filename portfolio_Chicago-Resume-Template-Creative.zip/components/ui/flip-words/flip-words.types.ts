export interface FlipWordsProps {
  words: string[];
  duration?: number;
  className?: string;
}