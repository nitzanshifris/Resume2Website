export * from "./background-gradient";
